package pcm;

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.sql.Date;
import pcm.Cliente;
import pcm.Turno;

// line 24 "model.ump"
// line 54 "model.ump"
public class Empleado
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Empleado Attributes
  private String nombre;
  private String apellido;
  private String cargo;

  //Empleado Associations
  private Turno turno;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Empleado(String aNombre, String aApellido, String aCargo, Turno aTurno)
  {
    nombre = aNombre;
    apellido = aApellido;
    cargo = aCargo;
    if (aTurno == null || aTurno.getEmpleado() != null)
    {
      throw new RuntimeException("Unable to create Empleado due to aTurno. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
    turno = aTurno;
  }

  public Empleado(String aNombre, String aApellido, String aCargo, int aNumero_turnoForTurno, String aFechaForTurno, String aTipoForTurno, Cliente aClienteForTurno)
  {
    nombre = aNombre;
    apellido = aApellido;
    cargo = aCargo;
    turno = new Turno(aNumero_turnoForTurno, aFechaForTurno, aTipoForTurno, aClienteForTurno, this);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setNombre(String aNombre)
  {
    boolean wasSet = false;
    nombre = aNombre;
    wasSet = true;
    return wasSet;
  }

  public boolean setApellido(String aApellido)
  {
    boolean wasSet = false;
    apellido = aApellido;
    wasSet = true;
    return wasSet;
  }

  public boolean setCargo(String aCargo)
  {
    boolean wasSet = false;
    cargo = aCargo;
    wasSet = true;
    return wasSet;
  }

  public String getNombre()
  {
    return nombre;
  }

  public String getApellido()
  {
    return apellido;
  }

  public String getCargo()
  {
    return cargo;
  }
  /* Code from template association_GetOne */
  public Turno getTurno()
  {
    return turno;
  }

  public void delete()
  {
    Turno existingTurno = turno;
    turno = null;
    if (existingTurno != null)
    {
      existingTurno.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "nombre" + ":" + getNombre()+ "," +
            "apellido" + ":" + getApellido()+ "," +
            "cargo" + ":" + getCargo()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "turno = "+(getTurno()!=null?Integer.toHexString(System.identityHashCode(getTurno())):"null");
  }
}