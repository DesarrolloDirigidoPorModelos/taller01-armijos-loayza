package pcm;

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.sql.Date;

// line 17 "model.ump"
// line 49 "model.ump"
public class Turno
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Turno Attributes
  private int numero_turno;
  private String fecha;
  private String tipo;

  //Turno Associations
  private Cliente cliente;
  private Empleado empleado;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Turno(int aNumero_turno, String aFecha, String aTipo, Cliente aCliente, Empleado aEmpleado)
  {
    numero_turno = aNumero_turno;
    fecha = aFecha;
    tipo = aTipo;
    boolean didAddCliente = setCliente(aCliente);
    if (!didAddCliente)
    {
      throw new RuntimeException("Unable to create turno due to cliente. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
    if (aEmpleado == null || aEmpleado.getTurno() != null)
    {
      throw new RuntimeException("Unable to create Turno due to aEmpleado. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
    empleado = aEmpleado;
  }

  public Turno(int aNumero_turno, String aFecha, String aTipo, Cliente aCliente, String aNombreForEmpleado, String aApellidoForEmpleado, String aCargoForEmpleado)
  {
    numero_turno = aNumero_turno;
    fecha = aFecha;
    tipo = aTipo;
    boolean didAddCliente = setCliente(aCliente);
    if (!didAddCliente)
    {
      throw new RuntimeException("Unable to create turno due to cliente. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
    empleado = new Empleado(aNombreForEmpleado, aApellidoForEmpleado, aCargoForEmpleado, this);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setNumero_turno(int aNumero_turno)
  {
    boolean wasSet = false;
    numero_turno = aNumero_turno;
    wasSet = true;
    return wasSet;
  }

  public boolean setFecha(String aFecha)
  {
    boolean wasSet = false;
    fecha = aFecha;
    wasSet = true;
    return wasSet;
  }

  public boolean setTipo(String aTipo)
  {
    boolean wasSet = false;
    tipo = aTipo;
    wasSet = true;
    return wasSet;
  }

  public int getNumero_turno()
  {
    return numero_turno;
  }

  public String getFecha()
  {
    return fecha;
  }

  public String getTipo()
  {
    return tipo;
  }
  /* Code from template association_GetOne */
  public Cliente getCliente()
  {
    return cliente;
  }
  /* Code from template association_GetOne */
  public Empleado getEmpleado()
  {
    return empleado;
  }
  /* Code from template association_SetOneToMany */
  public boolean setCliente(Cliente aCliente)
  {
    boolean wasSet = false;
    if (aCliente == null)
    {
      return wasSet;
    }

    Cliente existingCliente = cliente;
    cliente = aCliente;
    if (existingCliente != null && !existingCliente.equals(aCliente))
    {
      existingCliente.removeTurno(this);
    }
    cliente.addTurno(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Cliente placeholderCliente = cliente;
    this.cliente = null;
    if(placeholderCliente != null)
    {
      placeholderCliente.removeTurno(this);
    }
    Empleado existingEmpleado = empleado;
    empleado = null;
    if (existingEmpleado != null)
    {
      existingEmpleado.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "numero_turno" + ":" + getNumero_turno()+ "," +
            "tipo" + ":" + getTipo()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "fecha" + "=" + (getFecha() != null ? !getFecha().equals(this)  ? getFecha().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "cliente = "+(getCliente()!=null?Integer.toHexString(System.identityHashCode(getCliente())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "empleado = "+(getEmpleado()!=null?Integer.toHexString(System.identityHashCode(getEmpleado())):"null");
  }
}