package pcm;

public class main {

    public static void main(String[] args) {
        System.out.println("COPILANDO PROGRAMA DEL MAIN");
        System.out.println("CREANDO UNA EMPRESA");
        Empresa em = new Empresa("110121212", "23223232");
        em.setNombre_comercial("EM");
        em.setRuc("0705389524");
        System.out.println(em);
        System.out.println("CREANDO CLIENTE Y ASIGNANDOLE EMPRESA");
        Cliente c = new Cliente("Freddy", "Loayza", "0705035698 ", em);
        
         System.out.println("CREANDO TURNO PARA CLIENTE FREDDY Y PARA EL EMPLEADO MANUEL");
        Turno tu = new Turno(12, "2022-10-15", "medico", c, "Manuel", "Armijos", "11055932332 ");
        System.out.println(tu);
        
        
//        System.out.println("CREANDO EMPLEADO y asignandole turno y el cleinte Freddy");
//        Empleado emp = new Empleado("Freddy", "Loayza", "0705035698 ", 12, "2022-10-15", "medico", c );
//        System.out.println(emp);
}
}
