package pcm;

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.util.*;

// line 2 "model.ump"
// line 37 "model.ump"
public class Empresa
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Empresa Attributes
  private String ruc;
  private String nombre_comercial;

  //Empresa Associations
  private List<Cliente> clientes;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Empresa(String aRuc, String aNombre_comercial)
  {
    ruc = aRuc;
    nombre_comercial = aNombre_comercial;
    clientes = new ArrayList<Cliente>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setRuc(String aRuc)
  {
    boolean wasSet = false;
    ruc = aRuc;
    wasSet = true;
    return wasSet;
  }

  public boolean setNombre_comercial(String aNombre_comercial)
  {
    boolean wasSet = false;
    nombre_comercial = aNombre_comercial;
    wasSet = true;
    return wasSet;
  }

  public String getRuc()
  {
    return ruc;
  }

  public String getNombre_comercial()
  {
    return nombre_comercial;
  }
  /* Code from template association_GetMany */
  public Cliente getCliente(int index)
  {
    Cliente aCliente = clientes.get(index);
    return aCliente;
  }

  public List<Cliente> getClientes()
  {
    List<Cliente> newClientes = Collections.unmodifiableList(clientes);
    return newClientes;
  }

  public int numberOfClientes()
  {
    int number = clientes.size();
    return number;
  }

  public boolean hasClientes()
  {
    boolean has = clientes.size() > 0;
    return has;
  }

  public int indexOfCliente(Cliente aCliente)
  {
    int index = clientes.indexOf(aCliente);
    return index;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfClientes()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public Cliente addCliente(String aNombre, String aApellido, String aDni)
  {
    return new Cliente(aNombre, aApellido, aDni, this);
  }

  public boolean addCliente(Cliente aCliente)
  {
    boolean wasAdded = false;
    if (clientes.contains(aCliente)) { return false; }
    Empresa existingEmpresa = aCliente.getEmpresa();
    boolean isNewEmpresa = existingEmpresa != null && !this.equals(existingEmpresa);
    if (isNewEmpresa)
    {
      aCliente.setEmpresa(this);
    }
    else
    {
      clientes.add(aCliente);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeCliente(Cliente aCliente)
  {
    boolean wasRemoved = false;
    //Unable to remove aCliente, as it must always have a empresa
    if (!this.equals(aCliente.getEmpresa()))
    {
      clientes.remove(aCliente);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addClienteAt(Cliente aCliente, int index)
  {  
    boolean wasAdded = false;
    if(addCliente(aCliente))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfClientes()) { index = numberOfClientes() - 1; }
      clientes.remove(aCliente);
      clientes.add(index, aCliente);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveClienteAt(Cliente aCliente, int index)
  {
    boolean wasAdded = false;
    if(clientes.contains(aCliente))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfClientes()) { index = numberOfClientes() - 1; }
      clientes.remove(aCliente);
      clientes.add(index, aCliente);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addClienteAt(aCliente, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    for(int i=clientes.size(); i > 0; i--)
    {
      Cliente aCliente = clientes.get(i - 1);
      aCliente.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "ruc" + ":" + getRuc()+ "," +
            "nombre_comercial" + ":" + getNombre_comercial()+ "]";
  }
}