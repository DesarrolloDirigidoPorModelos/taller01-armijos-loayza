package pcm;

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/


import java.util.*;
import java.sql.Date;

// line 8 "model.ump"
// line 42 "model.ump"
public class Cliente
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Cliente Attributes
  private String nombre;
  private String apellido;
  private String dni;

  //Cliente Associations
  private Empresa empresa;
  private List<Turno> turnos;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Cliente(String aNombre, String aApellido, String aDni, Empresa aEmpresa)
  {
    nombre = aNombre;
    apellido = aApellido;
    dni = aDni;
    boolean didAddEmpresa = setEmpresa(aEmpresa);
    if (!didAddEmpresa)
    {
      throw new RuntimeException("Unable to create cliente due to empresa. See http://manual.umple.org?RE002ViolationofAssociationMultiplicity.html");
    }
    turnos = new ArrayList<Turno>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setNombre(String aNombre)
  {
    boolean wasSet = false;
    nombre = aNombre;
    wasSet = true;
    return wasSet;
  }

  public boolean setApellido(String aApellido)
  {
    boolean wasSet = false;
    apellido = aApellido;
    wasSet = true;
    return wasSet;
  }

  public boolean setDni(String aDni)
  {
    boolean wasSet = false;
    dni = aDni;
    wasSet = true;
    return wasSet;
  }

  public String getNombre()
  {
    return nombre;
  }

  public String getApellido()
  {
    return apellido;
  }

  public String getDni()
  {
    return dni;
  }
  /* Code from template association_GetOne */
  public Empresa getEmpresa()
  {
    return empresa;
  }
  /* Code from template association_GetMany */
  public Turno getTurno(int index)
  {
    Turno aTurno = turnos.get(index);
    return aTurno;
  }

  public List<Turno> getTurnos()
  {
    List<Turno> newTurnos = Collections.unmodifiableList(turnos);
    return newTurnos;
  }

  public int numberOfTurnos()
  {
    int number = turnos.size();
    return number;
  }

  public boolean hasTurnos()
  {
    boolean has = turnos.size() > 0;
    return has;
  }

  public int indexOfTurno(Turno aTurno)
  {
    int index = turnos.indexOf(aTurno);
    return index;
  }
  /* Code from template association_SetOneToMany */
  public boolean setEmpresa(Empresa aEmpresa)
  {
    boolean wasSet = false;
    if (aEmpresa == null)
    {
      return wasSet;
    }

    Empresa existingEmpresa = empresa;
    empresa = aEmpresa;
    if (existingEmpresa != null && !existingEmpresa.equals(aEmpresa))
    {
      existingEmpresa.removeCliente(this);
    }
    empresa.addCliente(this);
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfTurnos()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public Turno addTurno(int aNumero_turno, String aFecha, String aTipo, Empleado aEmpleado)
  {
    return new Turno(aNumero_turno, aFecha, aTipo, this, aEmpleado);
  }

  public boolean addTurno(Turno aTurno)
  {
    boolean wasAdded = false;
    if (turnos.contains(aTurno)) { return false; }
    Cliente existingCliente = aTurno.getCliente();
    boolean isNewCliente = existingCliente != null && !this.equals(existingCliente);
    if (isNewCliente)
    {
      aTurno.setCliente(this);
    }
    else
    {
      turnos.add(aTurno);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeTurno(Turno aTurno)
  {
    boolean wasRemoved = false;
    //Unable to remove aTurno, as it must always have a cliente
    if (!this.equals(aTurno.getCliente()))
    {
      turnos.remove(aTurno);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addTurnoAt(Turno aTurno, int index)
  {  
    boolean wasAdded = false;
    if(addTurno(aTurno))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTurnos()) { index = numberOfTurnos() - 1; }
      turnos.remove(aTurno);
      turnos.add(index, aTurno);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveTurnoAt(Turno aTurno, int index)
  {
    boolean wasAdded = false;
    if(turnos.contains(aTurno))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTurnos()) { index = numberOfTurnos() - 1; }
      turnos.remove(aTurno);
      turnos.add(index, aTurno);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addTurnoAt(aTurno, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    Empresa placeholderEmpresa = empresa;
    this.empresa = null;
    if(placeholderEmpresa != null)
    {
      placeholderEmpresa.removeCliente(this);
    }
    for(int i=turnos.size(); i > 0; i--)
    {
      Turno aTurno = turnos.get(i - 1);
      aTurno.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "nombre" + ":" + getNombre()+ "," +
            "apellido" + ":" + getApellido()+ "," +
            "dni" + ":" + getDni()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "empresa = "+(getEmpresa()!=null?Integer.toHexString(System.identityHashCode(getEmpresa())):"null");
  }
}